#!/bin/bash
timeout 8s /home/humandetector/prob.py
